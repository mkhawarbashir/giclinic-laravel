
<?php $__env->startSection('content'); ?>
<br/> <br/> <br/>



<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h2 class="page-title">New Disease Data Form</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <?php echo Form::open(['url' => '/addNewDisease', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                    
                            <div class="form-group">
                            <strong><?php echo e(Form::label('title', 'Disease Name')); ?><span class="text-danger">*</span></strong>
                            <?php echo Form::text('diseaseName', '', ['class'=>'form-control']); ?>

                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                            <strong><?php echo e(Form::label('title', 'Disease Description')); ?><span class="text-danger">*</span></strong>
                            <?php echo Form::textarea('desc', '', ['class'=>'form-control', 'rows'=>5]); ?>

                            </div>
                        </div>
                    </div>
                    <div class="m-t-20 text-center">
                        <!-- <?php echo Form::hidden('_method', 'PUT'); ?> -->
                        <?php echo Form::submit('Submit Disease Data', ['class' => 'btn btn-sl btn-info'] ); ?>

                        
                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

   <br/> <br/> <br/>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.clinicUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giclinic_laravel\resources\views/newDiseaseDataForm.blade.php ENDPATH**/ ?>