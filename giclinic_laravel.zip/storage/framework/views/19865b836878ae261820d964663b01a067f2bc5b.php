


<!--Commented out below flash-message using <?php ?> tags. [MN - 07.Jun.2020] -->


<?php $__env->startSection('content'); ?>
<!--<h1>$title within { and } comes here</h1>-->
    <!--<p>Where your health and life matters us!</p>-->
    <div class = "row">
        <h1>Blog Posts</h1>
    </div>
    <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                
                <div class = "row">
                    <div class = "col-md-0 col-sm-0" padding-left: 100px;>
                    <img src = "/storage/cover_images/<?php echo e($post->cover_image); ?>" width="50" height="50">
                    </div>
                    <div class = "col-md-9 col-sm-9">
                        <h3><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
                        <?php if($post->created_at->eq($post->updated_at)): ?>
                            <small>Written on: <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>    
                        <?php else: ?>
                            <small>Written on: <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small><br>
                            <small>Updated on: <?php echo e($post->updated_at); ?> by <?php echo e($post->user->name); ?></small>    
                        <?php endif; ?>
                    </div>
                </div>
            </div>
    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->links()); ?> <!--This will paginate the resultset. [MN - 11.06.2020]-->
    <?php else: ?>
        <p>No post found!</p>    
    
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.bloglayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giclinic_laravel\resources\views/posts/blog_index.blade.php ENDPATH**/ ?>