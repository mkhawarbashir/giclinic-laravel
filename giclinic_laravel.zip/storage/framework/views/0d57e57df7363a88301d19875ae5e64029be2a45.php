
<?php $__env->startSection('content'); ?>
<br/> <br/> <br/> <br/> <br/>
<form action="appointmentDetail" method="post" id="dateform">
<?php echo csrf_field(); ?>
  <div class="col-sm-6">
      <div class="form-group">
          <label>Select Date</label>
          <div class="cal-icon">
          <input type="date" name="datepicker" id="datepicker" class="form-control dynamic" required>
          <button type="submit" form="dateform" value="Submit">Submit</button>          
          </div>
      </div>

  </div>
</form>

<div class="table-responsive ">
    <table class="table table-striped w-auto" >
        <tr>
          <th>First Name</th>
          <th>Last Name</th>
          <th>CNIC</th>
          <th>Appointment Date</th>
          <th>Appointment Time</th>
          <th>City</th>
          <th>Contact Number</th>
          
        </tr>
    <?php $__currentLoopData = $patient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>    
          <td><?php echo e($data->first_name); ?></td>
          <td><?php echo e($data->last_name); ?></td>
          <td class='ptcnic'><a href="patientData/<?php echo e($data->cnic); ?>"><?php echo e($data->cnic); ?></a></td>
          <td><?php echo e($data->date); ?></td>
          <td><?php echo e($data->time); ?></td>
          <td><?php echo e($data->city); ?></td>
          <td><?php echo e($data->contact_number); ?></td>
          <!-- <td>
            <button value="Submit" type="submit" form="patientForm" class="editPatient"> Patient Data </button>
            
          </td> -->

        </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>
   <br/> <br/> <br/> <br/> <br/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.clinicUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giclinic_laravel\resources\views/appointmentDetails.blade.php ENDPATH**/ ?>