
<?php $__env->startSection('content'); ?>
<br/> <br/> <br/>



<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h2 class="page-title">Medicine Data Form</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <?php echo Form::open(['url' => '/addNewMedicine', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-6">
                    
                            <div class="form-group">
                            <strong><?php echo e(Form::label('title', 'Medicine Name')); ?><span class="text-danger">*</span></strong>
                            <?php echo Form::text('medname', '', ['class'=>'form-control']); ?>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                            <strong><?php echo e(Form::label('title', 'Medicine Type')); ?><span class="text-danger">*</span></strong>
                            <?php echo Form::text('medtype', '', ['class'=>'form-control']); ?>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                            <strong><?php echo e(Form::label('title', 'Company Name')); ?><span class="text-danger">*</span></strong>
                            <?php echo Form::text('medcomp', '', ['class'=>'form-control']); ?>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                            <strong><?php echo e(Form::label('title', 'Price')); ?><span class="text-danger">*</span></strong>
                            <?php echo Form::text('price', '', ['class'=>'form-control']); ?>

                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                            <strong><?php echo e(Form::label('title', 'Medicine Contents')); ?><span class="text-danger">*</span></strong>
                            <?php echo Form::textarea('medcontents', '', ['class'=>'form-control', 'rows'=>3]); ?>

                            </div>
                        </div>
                    </div>
                    <div class="m-t-20 text-center">
                        <!-- <?php echo Form::hidden('_method', 'PUT'); ?> -->
                        <?php echo Form::submit('Submit Medicine Data', ['class' => 'btn btn-sl btn-info'] ); ?>

                        
                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

   <br/> <br/> <br/>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.clinicUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giclinic_laravel\resources\views/newMedicineDataForm.blade.php ENDPATH**/ ?>