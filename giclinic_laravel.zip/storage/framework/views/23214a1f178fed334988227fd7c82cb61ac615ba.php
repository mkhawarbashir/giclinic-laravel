

<!--Created on . [MN - 07.Jun.2020] -->

<?php $__env->startSection('content'); ?>
    <!--Code block commented for testing the code after it. [MN - 11.06.2020]
        <a href="/posts" class="btn btn-default">Back</a>
        <h1>{ {$post->title}}</h1>
        <div>
            { {$post->body}}
        </div>
        <hr>
        <small>Written on: { {$post->created_at}}</small>
    -->


    <h1><?php echo e($post->title); ?></h1>
        <div>
            <?php echo $post->body; ?>   <!--Surrounding !! (double exclamation marks) will parse in browser 
                                    output any HTML produced through CKEditor. [MN - 11.06.2020]-->
        </div>
        <hr>
            <!--Compare created and updated dates and show only created_at if both 
                are same and both if both are different. [MN - 11.06.2020]-->    
        <?php if($post->created_at->eq($post->updated_at)): ?>
            <small>Written on: { {$post->created_at}} by { {$post->user->name}}</small>
        <?php else: ?>
            <small>Written on: <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small><br>
            <small>Updated on: <?php echo e($post->updated_at); ?> by <?php echo e($post->user->name); ?></small>    
        <?php endif; ?>
        <hr>
        <a href="/posts" class="btn btn-secondary">Back</a>
        <!--Added "if statement" below to remove Edit and Delete buttons for guest users.
            But any logged in user can still edit / delete other user's post. [MN - 28.06.2020] -->
        <?php if(!Auth::guest()): ?>
            <!--Added another "if statement" below to restrict a user to only edit / delete his/her post. [MN - 28.06.2020] -->
            <?php if(Auth::user()->id == $post->user_id): ?>
                <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary">Edit Post</a>
                <?php echo Form::open(['action' => ['BlogPagesController@destroy', $post->id], 'method' => 'POST', 'class' => 'float-right']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                <?php echo Form::close(); ?>

            <?php endif; ?>
        <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giclinic_laravel\resources\views/posts/blog_show.blade.php ENDPATH**/ ?>