@extends('layouts.clinicUser')
@section('content')
<br/> <br/> <br/> <br/> <br/>
<h3>Its in new page</h3>
   <br/> <br/> <br/> <br/> <br/>
@endsection
